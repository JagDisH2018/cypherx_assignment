import React, { useEffect } from "react";
import "./UserPage.css";
import { PiPlusThin } from "react-icons/pi";
import { PiDotsThreeLight } from "react-icons/pi";
import { LiaCircleSolid } from "react-icons/lia";
import { TbCircleDotted } from "react-icons/tb";
import { GrInProgress } from "react-icons/gr";
import { IoCheckmarkDoneCircle } from "react-icons/io5";
import { MdCancel } from "react-icons/md";

const UserPage = ({ tickets, users, theme }) => {
  const groupByUser = () => {
    return tickets.reduce((grouped, ticket) => {
      const userId = ticket.userId;
      grouped[userId] = grouped[userId] || [];
      grouped[userId].push(ticket);
      return grouped;
    }, {});
  };

  useEffect(() => {
    console.log(tickets);
    console.log(users);
  }, [tickets, users]);

  const findUserName = (userId) => {
    const user = users.find((user) => user.id === userId);
    return user ? user.name : "Unknown User";
  };

  const renderUserSections = () => {
    const groupedByUser = groupByUser();

    return (
      <div className={`user-container ${theme}`}>
        {Object.entries(groupedByUser).map(([userId, userTickets]) => (
          <div key={userId} className="user-section">
            <span>{findUserName(userId)}</span>
            {renderTickets(userTickets)}
          </div>
        ))}
      </div>
    );
  };

  const renderTickets = (tickets) => {
    return tickets
      ? tickets.map((ticket) => (
          <div key={ticket.id} className="ticket">
            <strong></strong> {ticket.id}
            <br />
            <strong>
              <span>
                {ticket.status === "In progress" ? (
                  <GrInProgress color="yellow" />
                ) : ticket.status === "Todo" ? (
                  <LiaCircleSolid />
                ) : ticket.status === "Backlog" ? (
                  <TbCircleDotted color="red" />
                ) : (
                  <div></div>
                )}
              </span>
            </strong>{" "}
            {ticket.title}
            <br />
          </div>
        ))
      : null;
  };

  return <div>{renderUserSections()}</div>;
};

export default UserPage;
